# app/main.py
from flask import Flask, render_template, request, jsonify
from motor_Inferencia import ExpertSystem

app = Flask(__name__)
system = ExpertSystem()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/agregar_tarea', methods=['POST'])
def agregar_tarea():
    data = request.get_json()
    system.add_task(data['id'], data['nombre'], data['prioridad'], data['tipo'])
    return jsonify({"status": "Tarea añadida con éxito"})

@app.route('/sugerencias')
def obtener_sugerencias():
    results = system.run()
    return jsonify(results)

if __name__ == '__app__':
    app.run(debug=True)
