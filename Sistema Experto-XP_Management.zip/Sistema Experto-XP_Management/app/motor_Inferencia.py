# app/motor_Inferencia.py
import clips

class ExpertSystem:
    def __init__(self):
        self.env = clips.Environment()
        self.env.load('app/base_Conocimiento.clp')

    def add_task(self, task_id, name, priority, task_type):
        """Agrega una tarea a la base de hechos."""
        task_fact = f'(tarea (id {task_id}) (nombre "{name}") (prioridad {priority}) (tipo {task_type}))'
        self.env.assert_string(task_fact)

    def run(self):
        """Ejecuta las reglas y devuelve las sugerencias y asignaciones."""
        self.env.run()
        suggestions = []
        resources = []
        
        for fact in self.env.facts():
            fact_str = str(fact)
            if fact_str.startswith("(sugerencia"):
                suggestions.append(fact_str)
            elif fact_str.startswith("(recurso"):
                resources.append(fact_str)
                
        return {"sugerencias": suggestions, "recursos": resources}
