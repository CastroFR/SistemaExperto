import sqlite3

def init_db():
    connection = sqlite3.connect('database.db')
    c = connection.cursor()
    
    # Crear tabla de proyectos
    c.execute('''
        CREATE TABLE IF NOT EXISTS proyectos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT
        )
    ''')
    
    # Crear tabla de programadores
    c.execute('''
        CREATE TABLE IF NOT EXISTS programadores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            experiencia INTEGER
        )
    ''')
    
    # Crear tabla de tareas
    c.execute('''
        CREATE TABLE IF NOT EXISTS tareas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            complejidad INTEGER
        )
    ''')
    
    # Insertar datos de ejemplo
    c.execute("INSERT INTO programadores (nombre, experiencia) VALUES (?, ?)", ('Juan', 3))
    c.execute("INSERT INTO programadores (nombre, experiencia) VALUES (?, ?)", ('Ana', 5))
    
    c.execute("INSERT INTO tareas (nombre, complejidad) VALUES (?, ?)", ('Desarrollar API', 4))
    c.execute("INSERT INTO tareas (nombre, complejidad) VALUES (?, ?)", ('Diseñar Base de Datos', 5))
    
    # Guardar cambios
    connection.commit()
    connection.close()
    print("Base de datos inicializada correctamente.")

if __name__ == '__main__':
    init_db()
