from flask import Flask, render_template, request
import clips
import sqlite3

# Inicializar la aplicación Flask
app = Flask(__name__)

# Ruta principal para mostrar la página de inicio
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Procesar la información del formulario
        programadores_input = request.form['programadores']
        tareas_input = request.form['tareas']
        
        # Parsear las entradas (se asume formato JSON o un formato estructurado)
        # Aquí se necesita una lógica para parsear correctamente las entradas
        import json
        try:
            programadores = json.loads(programadores_input)
            tareas = json.loads(tareas_input)
        except json.JSONDecodeError:
            return "Error en el formato de entrada. Asegúrate de usar JSON válido.", 400
        
        # Pasar la información a CLIPS como hechos
        recomendaciones = ejecutar_clips(tareas, programadores)
        
        # Mostrar las recomendaciones en la página resultados.html
        return render_template('resultados.html', recomendaciones=recomendaciones)
    return render_template('index.html')

def ejecutar_clips(tareas, programadores):
    # Cargar reglas CLIPS
    env = clips.Environment()
    env.load('clips_rules.clp')

    # Procesar programadores y tareas
    agregar_hechos(env, tareas, programadores)
    
    # Ejecutar las reglas
    env.run()

    # Recoger los resultados
    recomendaciones = []
    for fact in env.facts():
        if fact.template.name == "recomendacion":
            recomendacion = {
                'programador': fact['programador'],
                'tarea': fact['tarea']
            }
            recomendaciones.append(recomendacion)

    return recomendaciones

def agregar_hechos(env, tareas, programadores):
    # Añadir hechos de tareas y programadores a CLIPS
    for tarea in tareas:
        env.assert_string(f"(tarea (nombre \"{tarea['nombre']}\") (complejidad {tarea['complejidad']}))")
    for programador in programadores:
        env.assert_string(f"(programador (nombre \"{programador['nombre']}\") (experiencia {programador['experiencia']}))")

if __name__ == '__main__':
    app.run(debug=True)
