# Sistema Experto basado en Extreme Programming (XP)

## Requisitos
- **Python 3.x**
- **CLIPS**
- **Flask**

## Instalación

1.	**Instala las dependencias**:
   ```bash
   pip install -r requirements.txt

2.	Inicializa la base de datos ejecutando:
python init_db.py
3.	Ejecuta la aplicación Flask:
python app.py

4.	Abre tu navegador en http://127.0.0.1:5000 para interactuar con el sistema.













Uso
1.	Ingresar Datos:
o	En la página principal, ingresa la lista de programadores y tareas en formato JSON.
o	Ejemplo de Programadores:
[
    {"nombre": "Juan", "experiencia": 3},
    {"nombre": "Ana", "experiencia": 5}
]
o	Ejemplo de Tareas:
[
    {"nombre": "Desarrollar API", "complejidad": 4},
    {"nombre": "Diseñar Base de Datos", "complejidad": 5}
]

2.	Procesar Datos:
o	Haz clic en el botón Procesar.
o	Las recomendaciones se mostrarán en la página de resultados.

Notas

•	Asegúrate de que CLIPS esté correctamente instalado y configurado en tu sistema.
•	La entrada de datos debe estar en formato JSON válido para evitar errores de parseo.
